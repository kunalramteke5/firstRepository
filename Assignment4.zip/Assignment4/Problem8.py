# To reverse each word in python

x=input("Enter the text: ")
b=x[::-1].split(" ")
b.reverse()
c=" ".join(b)
print(c)

