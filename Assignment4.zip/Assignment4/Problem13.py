# To convert temp from farhenheit to celcius
a=float(input("Enter the temp in farhenheit: "))
c=(5/9)*(a-32)
print("The tenp in celcius is: ",c)